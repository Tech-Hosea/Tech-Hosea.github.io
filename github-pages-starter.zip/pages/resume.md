---
layout: page
title: "Resume"
permalink: /resume/
---

[Download My Resume (PDF)](/assets/img/resume.pdf)

## Experience
- IT Intern @ Fulton County
- Crew Member @ Chipotle (Team Collaboration, Fast-Paced Problem Solving)

## Skills
- Windows Server, Active Directory, Intune
- pfSense, VLANs, DHCP, DNS
