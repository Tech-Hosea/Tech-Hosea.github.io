---
layout: page
title: "Certifications"
permalink: /certifications/
---

- CompTIA Security+
- CompTIA Network+
- Microsoft 365 Certified: Fundamentals
