---
layout: page
title: "About Me"
permalink: /about/
---

I'm an aspiring IT Support Specialist transitioning into Cybersecurity. This site showcases my homelab projects and learning journey.
