---
layout: post
title: "WSUS Server Setup"
date: 2025-06-20
thumbnail: "/assets/img/wsus-thumb.jpg"
---

## Overview
- WSUS installed on Windows Server
- Devices grouped via GPO
- Patch reports scheduled weekly
